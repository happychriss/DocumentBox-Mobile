package com.db.mobile

import kotlinx.coroutines.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.*
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.io.FileNotFoundException
import java.text.SimpleDateFormat
import java.util.*
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.icu.text.IDNA
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.net.wifi.SupplicantState
import android.os.AsyncTask
import android.os.AsyncTask.execute
import android.provider.Settings
import android.provider.SyncStateContract.Helpers.update
import android.util.Log
import android.widget.Button
import androidx.core.content.FileProvider
import com.github.kittinunf.fuel.Fuel
import com.github.kittinunf.fuel.core.*
import com.github.kittinunf.fuel.coroutines.awaitString
import com.github.kittinunf.fuel.coroutines.awaitStringResponse
import com.yalantis.ucrop.UCrop
import java.io.IOException
import java.nio.charset.Charset
import kotlin.concurrent.thread
import kotlin.system.exitProcess


class MainActivity : AppCompatActivity() {


    var camera_image_uri = Uri.EMPTY
    //    private val CDSERVER = "http://192.168.1.101:8082" //CT

    private val CDSERVER = "http://192.168.1.100:3000" //Donald
    private val valid_wifis = setOf("Alice-WLANXP", "Alice-WLANXP5", "AndroidWifi")

    private val CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 100
    internal val context: Context = this

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup listener ********** Prepare View ****************

        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.my_toolbar))

        val button_scan = findViewById<Button>(R.id.scann)
        val button_upload = findViewById<Button>(R.id.upload)

        val progressBar = findViewById<ProgressBar>(R.id.determinateBar) as ProgressBar
        val statusMessage = findViewById<TextView>(R.id.statusView)
        progressBar.visibility = View.INVISIBLE
        statusMessage.text = "Scans to upload: " + Integer.toString(getUploadFiles().size)

        // Setup listener ********** Scanner ****************

        button_scan.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                camera_image_uri = FileProvider.getUriForFile(
                    getApplicationContext(),
                    "com.db.mobile.fileprovider",
                    getFile("camera")
                )
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                intent.putExtra(MediaStore.EXTRA_OUTPUT, camera_image_uri)
                startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE)
            }
        })

        // Setup listener ********** Upload  ****************


        button_upload.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {

                if (SetUpWifi()) return

                var error = false

                runBlocking {
                    try {
                        Fuel.get("$CDSERVER/cd_server_status_for_mobile").awaitStringResponse()
                    } catch (exception: Exception) {
                        showMessage("Could not find DocBox Server")
                        error = true
                    }
                }

                if (!error) {

                    // we need this thread to update the user-interface in the for loopo
                    thread {

                        runOnUiThread(java.lang.Runnable {
                            progressBar.progress = 0
                            progressBar.max = getUploadFiles().size
                            progressBar.visibility = View.VISIBLE
                        })

                        for (file in getUploadFiles()) {
                            uploadFile(file)
                        }

                        runOnUiThread(java.lang.Runnable {
                            progressBar.visibility = View.INVISIBLE
                        })
                    } // end of threat

                }

            }

        }) // end of button_upload


    }

// ********************************************************************************************
// ********************************************************************************************

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

// *********************** CROP ***************************************************************

        if (requestCode == UCrop.REQUEST_CROP) {

            if (data != null) {
                if (resultCode == Activity.RESULT_OK) {
                    val f_camera = File(camera_image_uri.path!!)
                    f_camera.delete()
                }
            }
        }

// ****** SCAN *************************************************

        if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {


                val crop = UCrop.Options()
                crop.setFreeStyleCropEnabled(true)
                crop.setHideBottomControls(true)
                crop.setToolbarTitle("Crop done")

                UCrop.of(camera_image_uri, Uri.fromFile(getFile("crop")))
                    .withOptions(crop)
                    .start(this)

                // Image captured and saved to fileUri specified in the Intent

            } else if (resultCode == Activity.RESULT_CANCELED) {
                // User cancelled the image capture
            } else {
                // Image capture failed, advise user
            }
        }

        var statusMessage = findViewById<TextView>(R.id.statusView)
        statusMessage.text = "Scans to upload: " + Integer.toString(getUploadFiles().size)

    }


    /// ************************** Supporting functions *********************************************
    private fun SetUpWifi(): Boolean {
        // Check if location determination is enabled for the app ******************
        if ((context.getSystemService(Activity.LOCATION_SERVICE) as LocationManager).getProviders(
                true
            ).size == 0
        ) {
            context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            showMessage("Grant app Permission to Location (to read SSID")
            return true
        }

        // Check Wifi Connection **********************************

        val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (wifiManager.connectionInfo.supplicantState != SupplicantState.COMPLETED) {
            showMessage("Error: Not connected to Wifi")
            return true
        }
        val wifiInfo = wifiManager.connectionInfo
        var ssid = wifiInfo.ssid

        if (ssid!!.startsWith("\"") && ssid.endsWith("\"")) {
            ssid = ssid.substring(1, ssid.length - 1)
        }

        if (!valid_wifis.contains((ssid))) {
            showMessage("Error: Connected to $ssid, but need:${valid_wifis}")
            return true
        }
        return false
    }


    private fun showMessage(message: CharSequence) {
        val altDialog = AlertDialog.Builder(context)
        altDialog.setMessage(message) // here add your message
        altDialog.show()
    }


    private fun getUploadFiles(): Array<File> {
        val path = getExternalFilesDir(Environment.DIRECTORY_PICTURES)

        val files = path!!.listFiles { file ->
            file.length() > 0 && file.name.startsWith("DB_crop")
        }

        return files!!
    }


    private fun uploadFile(file: File) {
        val progressBar = findViewById<ProgressBar>(R.id.determinateBar) as ProgressBar
        val statusMessage = findViewById<TextView>(R.id.statusView)

        if (file.isFile) { //this line weeds out other directories/folders
            runBlocking {

                try {
                    Fuel.upload("$CDSERVER/upload_mobile")
                        .add {
                            FileDataPart(
                                file,
                                name = "upload_file",
                                filename = file.name
                            )
                        }
                        .awaitStringResponse()
                } catch (exception: Exception) {
                    showMessage("Could not find DocBox Server")
                }
            }

            file.delete()

            Thread.sleep(2000)

            runOnUiThread(java.lang.Runnable {
                progressBar.incrementProgressBy(1)
                statusMessage.text = "Scans to upload: " + getUploadFiles().size
            })

        }


    }


    @Throws(IOException::class)

    private fun getFile(prefix: String): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "DB_${prefix}_JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        )

    }


}

